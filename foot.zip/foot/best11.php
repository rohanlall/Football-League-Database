<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Players in 4-3-3 Formation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        .formation {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin: 20px;
        }

        .position {
            font-weight: bold;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "Samarth@123";
$dbname = "foot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to get the best players for each position
$positionQuery = "SELECT p.Position, p.BestPlayerRate, CONCAT(pl.FirstName, ' ', pl.LastName) AS PlayerName
FROM (
    SELECT Position, MAX(Playerrate) AS BestPlayerRate
    FROM Players
    GROUP BY Position
) p
JOIN Players pl ON p.Position = pl.Position AND p.BestPlayerRate = pl.Playerrate;
";
$result = $conn->query($positionQuery);
if ($result->num_rows > 0) {
    echo "<h2>Best Players in 4-3-3 Formation</h2>";
    echo "<div class='formation'>";

    while ($row = $result->fetch_assoc()) {
        $position = $row['Position'];
        $playerName = $row['PlayerName'];
        $rating = $row['BestPlayerRate'];

        echo "<div>";
        echo "<div class='position'>$position</div>";
        echo "<div>$playerName</div>";
        echo "<div>Rating: $rating</div>";
        echo "</div>";
    }

    echo "</div>";
} else {
    echo "0 results found";
}

$conn->close();
?>

</body>
</html>
