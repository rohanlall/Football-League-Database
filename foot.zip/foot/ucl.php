<?php
$conn = mysqli_connect('localhost:3306', 'root', 'Samarth@123', 'foot1');
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}

$sql = "SELECT * FROM last WHERE teamID IN (SELECT teamID FROM teams WHERE Leagueid='L2')";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background-color: #3498db;
            color: white;
            font-family: Arial, sans-serif;
            text-align: center;
            padding-top: 50px;
        }

        input[type="submit"] {
            background-color: black;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #27ae60;
        }

        table {
            margin-top: 20px;
        }

        .back-to-home {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: black;
            color: white;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
    </style>
</head>
<body>
    <a href="index.php" class="back-to-home">
        <button>Back to Home</button>
    </a>

    <form method="post">
        <input type="submit" name="generateButton" value="Generate the Best 11">
    </form>

    <?php
if ($result->num_rows > 0) {
    echo "<table align='center' border='2px' style='width:1000px; line-height:40px; text-align: center;'> 
        <tr> 
            <th colspan='9'>La Liga Standings</th> 
        </tr> 
        <tr>
            <th style='width: 111px;'>TeamID</th>
            <th style='width: 111px;'>Matches Played</th>
            <th style='width: 111px;'>Wins</th>
            <th style='width: 111px;'>Losses</th>
            <th style='width: 111px;'>Draws</th>
            <th style='width: 111px;'>Stats</th>
            <th style='width: 111px;'>Team Name</th>
            <th style='width: 111px;'>Generate Last 5 Matches</th>
        </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["l_id"] . "</td>
                <td>" . $row["l_match"] . "</td>
                <td>" . $row["l_win"] . "</td>
                <td>" . $row["l_lose"] . "</td>
                <td>" . $row["l_draw"] . "</td>
                <td>" . $row["l_stats"] . "</td>
                <td>" . $row["teamID"] . "</td>
                <td>" . $row["teamname"] . "</td>
                <td><form method='post'><input type='hidden' name='teamID' value='" . $row["teamID"] . "'><input type='submit' name='lastMatchesButton' value='Get Last 5 Matches'></form></td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "0 results found";
}

// Check if the last matches button is clicked
if (isset($_POST['lastMatchesButton'])) {
    $selectedTeamID = $_POST['teamID'];

    // Your code to retrieve the last 5 matches values for the selected team goes here
    // You can execute a query or call a stored procedure based on your database schema and requirements

    // Example: Display a message for demonstration purposes
    echo "Fetching last 5 matches for TeamID: " . $selectedTeamID;
}
?>

</body>
</html>
