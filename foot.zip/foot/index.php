



<script>
    document.addEventListener("DOMContentLoaded", function() {
        const buyButtons = document.querySelectorAll(".buy-button");

        buyButtons.forEach(button => {
            button.addEventListener("click", function() {
                const name = this.getAttribute("data-name");
                const price = parseFloat(this.getAttribute("data-price"));

                // Ask the user for the quantity
                const quantityInput = prompt(`Enter the quantity you want to buy for ${name}:`);
                const quantity = parseInt(quantityInput);

                // Check if the quantity is valid
                if (!isNaN(quantity) && quantity > 0) {
                    const totalCost = price * quantity;

                    // Ask for confirmation before making a purchase
                    const confirmation = window.confirm(`Confirm purchase of ${quantity} unit(s) of ${name} for $${totalCost}?`);
                    if (!confirmation) {
                        return; // If the user cancels the confirmation, do not proceed with the purchase
                    }

                    // Update quantity displayed in the HTML
                    const quantityLeftElement = this.closest('.item').querySelector('.quantity-left');
                    const currentQuantity = parseInt(quantityLeftElement.textContent);
                    if (currentQuantity >= quantity) {
                        quantityLeftElement.textContent = currentQuantity - quantity;
                    } else {
                        alert("Not enough quantity available!");
                        return;
                    }

                    // Debugging: Print values to console

                    // Send data to server using AJAX
                    const xhr = new XMLHttpRequest();
                    xhr.open("POST", "buy.php", true);
                    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    xhr.onreadystatechange = function() {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            // Handle server response if needed
                            console.log(xhr.responseText);
                        }
                    };
                    xhr.send(`name=${name}&quantity=${quantity}&totalcost=${totalCost}`);

                    // Redirect to confirm.php with item details as query parameters
                    window.location.href = `confirm.php?name=${encodeURIComponent(name)}&quantity=${encodeURIComponent(quantity)}&price=${encodeURIComponent(totalCost)}`;
                } else {
                    alert("Invalid quantity. Please enter a valid number.");
                }
            });
        });
    });
</script>







<?php
$servername = "localhost"; // Change this to your database server name
$username = "root"; // Change this to your database username
$password = "Samarth@123"; // Change this to your database password
$dbname = "foot1"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql1 = "SELECT kit_id, quantity, price, name_k FROM kits WHERE name_k = 'FCB'";
$sql2 = "SELECT kit_id, quantity, price, name_k FROM kits WHERE name_k = 'Chelsea'";
$sql3 = "SELECT kit_id, quantity, price, name_k FROM kits WHERE name_k = 'Man City'";
$result1 = $conn->query($sql1);
$result2 = $conn->query($sql2);
$result3 = $conn->query($sql3);
$conn->close();
?>




<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Hexashop Ecommerce HTML CSS Template</title>


    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/templatemo-hexashop.css">

    <link rel="stylesheet" href="assets/css/owl-carousel.css">

    <link rel="stylesheet" href="assets/css/lightbox.css">
<!--

TemplateMo 571 Hexashop

https://templatemo.com/tm-571-hexashop

-->
    </head>
    
    <body>
    
    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->
    
    
    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.php" class="logo">
                            <img src="assets/images/logo.png">
                        </a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
                            <li class="scroll-to-section"><a href="#men">Leagues</a></li>
                            <li class="scroll-to-section"><a href="#women">Football Kits</a></li>
                            <li class="scroll-to-section"><a href="users.php">Users</a></li>
                            <li class="scroll-to-section"><a href="#" onclick="confirmLogout()">Logout</a></li>

                            <!--<li class="submenu">
                                <a href="javascript:;">Pages</a>
                                <ul>
                                    <li><a href="about.html">About Us</a></li>
                                    <li><a href="products.html">Products</a></li>
                                    <li><a href="single-product.html">Single Product</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </li> 
                            <li class="submenu">
                                <a href="javascript:;">Features</a>
                                <ul>
                                    <li><a href="#">Features Page 1</a></li>
                                    <li><a href="#">Features Page 2</a></li>
                                    <li><a href="#">Features Page 3</a></li>
                                    <li><a rel="nofollow" href="https://templatemo.com/page/4" target="_blank">Template Page 4</a></li>
                                </ul>
                            </li>
                            <li class="scroll-to-section"><a href="#explore">Explore</a></li>
                        </ul> -->      
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Main Banner Area Start ***** -->
    <div class="main-banner" id="top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6">
                    <div class="left-content">
                        <div class="thumb">
<!--                            <div class="inner-content">
                                <h4>We Are Hexashop</h4>
                                <span>Awesome, clean &amp; creative HTML5 Template</span>
                                <div class="main-border-button">
                                    <a href="#">Purchase Now!</a>
                                </div>
                            </div> -->
                            <img src="assets/images/mp.jpg" alt="" width="700" height="570">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="right-content">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                       <!-- <div class="inner-content">
                                            <h4>Women</h4>
                                            <span>Best Clothes For Women</span>
                                        </div>
                                       <div class="hover-content">
                                            <div class="inner">
                                                <h4>Women</h4>
                                                <p>Lorem ipsum dolor sit amet, conservisii ctetur adipiscing elit incid.</p>
                                                <div class="main-border-button">
                                                    <a href="#">Discover More</a>
                                                </div>
                                            </div>
                                        </div>-->
                                        <img src="assets/images/first.jpg" width="400" height="270">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                      <!--  <div class="inner-content">
                                            <h4>Men</h4>
                                            <span>Best Clothes For Men</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4>Men</h4>
                                                <p>Lorem ipsum dolor sit amet, conservisii ctetur adipiscing elit incid.</p>
                                                <div class="main-border-button">
                                                    <a href="#">Discover More</a>
                                                </div>
                                            </div>
                                        </div> -->
                                        <img src="assets/images/sec.jpg" width="400" height="270">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                      <!--  <div class="inner-content">
                                            <h4>Kids</h4>
                                            <span>Best Clothes For Kids</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4>Kids</h4>
                                                <p>Lorem ipsum dolor sit amet, conservisii ctetur adipiscing elit incid.</p>
                                                <div class="main-border-button">
                                                    <a href="#">Discover More</a>
                                                </div>
                                            </div>
                                        </div>-->
                                        <img src="assets/images/third.jpg" width="400" height="270">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="right-first-image">
                                    <div class="thumb">
                                        <!--<div class="inner-content">
                                           <h4>Accessories</h4>
                                            <span>Best Trend Accessories</span>
                                        </div>
                                        <div class="hover-content">
                                            <div class="inner">
                                                <h4>Accessories</h4>
                                                <p>Lorem ipsum dolor sit amet, conservisii ctetur adipiscing elit incid.</p>
                                                <div class="main-border-button">
                                                    <a href="#">Discover More</a>
                                                </div>
                                            </div>
                                        </div>-->
                                        <img src="assets/images/for.jpg" width="400" height="270">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->


    <!-- ***** Men Area Starts ***** -->
    <section class="section" id="men">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-heading">
                        <h2>Leagues</h2>
                        <span>Shows the League Standings of each Leagues </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="men-item-carousel">
                        <div class="owl-men-item owl-carousel">
                            <div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                            <li><a href="laliga.php">Click</i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/lalig.jpg" alt="" width="600" height="400">
                                </div>
                                <div class="down-content">
                                    <h4>Laliga</h4>
                                    <!--<ul class="stars">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                        <li><a href="pl.php">Click</i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/pl.jpg" alt="" width="600" height="400">
                                </div>
                                <div class="down-content">
                                    <h4>Premier League</h4>
                                    <!--<ul class="stars">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>-->
                                </div>
                            </div>
                            <div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                        <li><a href="bund.php">Click</i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/bl.png" alt="" width="600" height="400">
                                </div>
                                <div class="down-content">
                                    <h4>Bundesliga</h4>
                                    <!--<ul class="stars">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>-->
                                </div>
                            </div>
                            <!--<div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                            <li><a href="single-product.html"><i class="fa fa-eye"></i></a></li>
                                            <li><a href="single-product.html"><i class="fa fa-star"></i></a></li>
                                            <li><a href="single-product.html"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/men-01.jpg" alt="">
                                </div>
                                <div class="down-content">
                                    <h4>Classic Spring</h4>
                                    <span>$120.00</span>
                                    <ul class="stars">
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                        <li><i class="fa fa-star"></i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Men Area Ends ***** -->
    <!-- ***** Men Area Starts ***** -->


    <!-- ***** Women Area Starts ***** -->
    <section class="section" id="women">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-heading">
                        <h2>Buy Football Kits</h2>
                        <span>Team Kits</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="women-item-carousel">
                        <div class="owl-women-item owl-carousel">
                        <!-- FCB -->    
                        <div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                            <li><a href="single-product.html"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/fcb.jpg" alt="">
                                </div>
                                <button class="buy-button" data-name="FCB" data-price="1000.00" style="background-color: blue; /* Green */
  border: none;
  color: white;
  padding: 10px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 8px;">Buy</button>
                                <?php
                                    if ($result1->num_rows > 0) {
                                    while($row = $result1->fetch_assoc()) {
                                    echo '<div class="col-lg-12">';
                                        echo '<h4>' . $row['name_k'] . '</h4>';
                                        echo '<p>Quantity Left: <span class="quantity-left">' . $row['quantity'] . '</span></p>';
                                        echo '<p>Price: $' . $row['price'] . '</p>';
                                    echo '</div>';
                                     }
                                        } else {
                                        echo "0 results found";
                                }
                                    ?>
                            </div>
                                                    <!-- Chel -->   
                            <div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                            <li><a href="single-product.html"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/chel.jpg" alt="">
                                </div>
                                <button class="buy-button" data-name="Chelsea" data-price="600.00" style="background-color: blue; /* Green */
  border: none;
  color: white;
  padding: 10px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 8px;">Buy</button>

                                <?php
                                    if ($result2->num_rows > 0) {
                                    while($row = $result2->fetch_assoc()) {
                                    echo '<div class="col-lg-12">';
                                        echo '<h4>' . $row['name_k'] . '</h4>';
                                        echo '<p>Quantity Left: <span class="quantity-left">' . $row['quantity'] . '</span></p>';
                                        echo '<p>Price: $' . $row['price'] . '</p>';
                                    echo '</div>';
                                     }
                                        } else {
                                        echo "0 results found";
                                }
                                    ?>
                            </div>
                                                    <!-- MC -->   
                            <div class="item">
                                <div class="thumb">
                                    <div class="hover-content">
                                        <ul>
                                            <li><a href="single-product.html"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <img src="assets/images/mc.jpg" alt="">
                                </div>
                                <button class="buy-button" data-name="Man City" data-price="800.00" style="background-color: blue; /* Green */
  border: none;
  color: white;
  padding: 10px 30px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 8px;">Buy</button>
                                <?php
                                    if ($result3->num_rows > 0) {
                                    while($row = $result3->fetch_assoc()) {
                                    echo '<div class="col-lg-12">';
                                        echo '<h4>' . $row['name_k'] . '</h4>';
                                        echo '<p>Quantity Left: <span class="quantity-left">' . $row['quantity'] . '</span></p>';
                                        echo '<p>Price: $' . $row['price'] . '</p>';
                                    echo '</div>';
                                     }
                                        } else {
                                        echo "0 results found";
                                }
                                    ?>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/accordions.js"></script>
    <script src="assets/js/datepicker.js"></script>
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/slick.js"></script> 
    <script src="assets/js/lightbox.js"></script> 
    <script src="assets/js/isotope.js"></script> 
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

    <script>

        $(function() {
            var selectedClass = "";
            $("p").click(function(){
            selectedClass = $(this).attr("data-rel");
            $("#portfolio").fadeTo(50, 0.1);
                $("#portfolio div").not("."+selectedClass).fadeOut();
            setTimeout(function() {
              $("."+selectedClass).fadeIn();
              $("#portfolio").fadeTo(50, 1);
            }, 500);
                
            });
        });

    </script>
    <script>
    function confirmLogout() {
        var confirmation = confirm("Are you sure you want to logout?");
        if (confirmation) {
            // If the user confirms, redirect to login.html
            window.location.href = "login.html";
        } else {
            // If the user cancels, do nothing
        }
    }
</script>

  </body>
</html>