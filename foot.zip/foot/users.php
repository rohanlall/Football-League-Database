<?php
// Assuming you have a database connection established
$servername = "localhost";
$username = "root";
$password = "Samarth@123";
$dbname = "foot1";

$conn = new mysqli($servername, $username, $password, $dbname);

function isUserAdmin($email)
{
    global $conn;
    $query = "SELECT role FROM login WHERE email = '$email'";
    $result = $conn->query($query);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row["role"] === "admin";
    }
    return false;
}


// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle user deletion if the request is a POST request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_user"])) {
    $userEmail = $_POST["delete_user"];
    
    // Perform the user deletion from the login table
    $deleteQuery = "DELETE FROM login WHERE email = '$userEmail'";
    $conn->query($deleteQuery);
}

// Retrieve names and emails from the login table
$query = "SELECT name_s, email FROM login";
$result = $conn->query($query);

// Display the results in a styled HTML table
echo "<html><head><title>User List</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 20px;
    }
    h2 {
        color: #333;
    }
    table {
        width: 60%;
        margin-top: 20px;
        border-collapse: collapse;
        border: 1px solid #ddd;
        background-color: #fff;
    }
    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #4CAF50;
        color: white;
    }
    tr:hover {
        background-color: #f5f5f5;
    }
    .delete-button {
        background-color: #f44336;
        color: white;
        border: none;
        padding: 5px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 12px;
        cursor: pointer;
    }
</style>
</head><body>";
echo "<h2>User List</h2>";
echo "<table border='1'>
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Action</th>
    </tr>";

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>".$row["name_s"]."</td>
            <td>".$row["email"]."</td>
            <td>";
            
        // Check if the user is admin before showing the delete button
        if (!isUserAdmin($row["email"])) {
            echo "<button class='delete-button' onclick='confirmDelete(\"".$row["email"]."\")'>Delete</button>";
        } else {
            echo "N/A";
        }

        echo "</td></tr>";
    }
} else {
    echo "<tr><td colspan='3'>No users found</td></tr>";
}

echo "</table>";

// JavaScript function to confirm deletion and make AJAX request
echo "<script>
    function confirmDelete(userEmail) {
        if (confirm('Are you sure you want to delete this user?')) {
            // Make an AJAX request to delete the user
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Reload the page after deletion
                    location.reload();
                }
            };
            xhr.open('POST', 'users.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send('delete_user=' + userEmail);
        }
    }
</script>";

echo "</body></html>";

// Close the database connection
$conn->close();
?>