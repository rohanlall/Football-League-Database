<?php
$servername = "localhost";
$username = "root";
$password = "Samarth@123";
$dbname = "foot1";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $quantity = $_POST["quantity"];
    $totalCost = $_POST["totalcost"];
    $p_id = uniqid(); // Generate a unique purchase ID

    // Insert purchase record into purchases table
    $sql_insert_purchase = "INSERT INTO purchases (p_id, name_k, quantity, totalcost) VALUES ('$p_id', '$name', '$quantity', '$totalCost')";

    // Update quantity in kits table
    $sql_update_kits = "UPDATE kits SET quantity = quantity - $quantity WHERE name_k = '$name'";

    // Perform both queries in a transaction to ensure data consistency
    $conn->begin_transaction();

    try {
        // Insert purchase record
        $conn->query($sql_insert_purchase);

        // Update quantity in kits table
        $conn->query($sql_update_kits);

        // Commit the transaction
        $conn->commit();

        echo "Purchase successful!";
    } catch (Exception $e) {
        // Rollback the transaction on error
        $conn->rollback();

        echo "Error: " . $e->getMessage();
    }
}

$conn->close();
?>


