<style>
    .back-to-home {
		background-color: green;
        color: white;
        font-size: 16px;   
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
</style> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            text-align: center;
        }

        h1 {
            color: #333;
        }

        h2 {
            color: #009688;
        }

        h3 {
            color: #555;
        }

        h4 {
            color: #555;
        }

        p {
            color: #777;
        }

        .confirmation-container {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="confirmation-container">
        <h1>Order Confirmation</h1>
        <?php
// Retrieve item details from query parameters
$itemName = $_GET['name'] ?? '';
$itemQuant = $_GET['quantity'] ?? '';
$itemPrice = $_GET['price'] ?? '';

// Display purchased item details
echo '<h2>You have successfully purchased the kit of: ' . $itemName .'</h2>';
echo '<h4>Quantity: ' . $itemQuant . '</h4>';
echo '<h3>Total Price: $' . $itemPrice . '</h3>';

        ?>
        <p>Thank you for your purchase!</p>
    </div>
</body>
<a href="index.php" class="back-to-home">
        <button>Back to Home</button>
</a>
</html>
