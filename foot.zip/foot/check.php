<?php
// Establish a MySQLi connection
$conn = new mysqli('localhost', 'root', 'Samarth@123', 'foot1');

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$email = $_POST['email'];
$pass = $_POST['pass'];

// Validate data (perform more extensive validation as needed)
if(empty($email) || empty($pass)) {
    echo "Email and password are required.";
} else {
    // Prepare SQL query to check email and password
    $sql = "SELECT * FROM login WHERE email='$email' AND pass='$pass'";
    $result = $conn->query($sql);

    // Check if a row is returned
    if ($result->num_rows > 0) {
        // Redirect to index.php if email and password are correct
        header("Location: index.php");
        exit();
    } else {
        echo "Invalid email or password.";
    }
}

// Close the connection
$conn->close();
?>
