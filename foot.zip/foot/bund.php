<style>
    body {
        background-color: #3498db;
        color: white;
        font-family: Arial, sans-serif;
        text-align: center;
        padding-top: 50px;
    }

    input[type="submit"] {
        background-color: black;
        color: white;
        padding: 10px 20px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #27ae60;
    }

    table {
        margin-top: 20px;
    }

    .back-to-home {
        position: absolute;
        top: 10px;
        right: 10px;
		background-color: black;
        color: white;
        padding: 10px 20px;
        font-size: 16px;   
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }
</style>
</head>
<body>
	<a href="index.php" class="back-to-home">
        <button>Back to Home</button>
    </a>
    <form method="post">
        <input type="submit" name="generateButton" value="Generate the Best 11">
    </form>
    <form method="post" class="team-form">
        <label for="teamName">Enter Team Name:</label>
        <input type="text" name="teamName" required>
        <input type="submit" name="getTeamTable" value="Get Team Table">
    </form>
    
</body>
</html>



<?php 

$conn = mysqli_connect('localhost:3306','root','Samarth@123','foot1');
if (!$conn) {
    die('Connection failed: ' . mysqli_connect_error());
}  

$sql = "SELECT * FROM standings where Leagueid='L1' ORDER BY Points DESC, GoalDifference DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table align='center' border='2px' style='width:1000px; line-height:40px; text-align: center;'> 
    <tr> 
        <th colspan='9'>Premier League</th> 
    </tr> 
    <tr>
        <th style='width: 111px;'>TeamName</th>
        <th style='width: 111px;'>Points</th>
        <th style='width: 111px;'>MatchesPlayed</th> 
        <th style='width: 111px;'>Wins</th>
        <th style='width: 111px;'>Draws</th>
        <th style='width: 111px;'>Losses</th>
        <th style='width: 111px;'>GoalsFor</th>
        <th style='width: 111px;'>GoalsAgainst</th>
        <th style='width: 111px;'>GoalDifference</th>
    </tr>";

    while($row = $result->fetch_assoc()) {
        $wins = $row["Wins"];
        $draws = $row["Draws"];
        $losses = $row["MatchesPlayed"] - ($wins + $draws);
        $points = (3 * $wins) + $draws;
        $goalDifference = $row["GoalsFor"] - $row["GoalsAgainst"];

        echo "<tr>
                <td>".$row["TeamName"]."</td>
                <td>".$points."</td>
                <td>".$row["MatchesPlayed"]."</td>
                <td>".$wins."</td>
                <td>".$draws."</td>
                <td>".$losses."</td>
                <td>".$row["GoalsFor"]."</td>
                <td>".$row["GoalsAgainst"]."</td>
                <td>".$goalDifference."</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "0 results found";
}

// Check if the button is clicked
if(isset($_POST['generateButton'])){
// Your database connection code here


// DELIMITER //

// CREATE PROCEDURE GetBestPlayers()
// BEGIN
//     SELECT p.Position, p.BestPlayerRate, CONCAT(pl.FirstName, ' ', pl.LastName) AS PlayerName
//     FROM (
//         SELECT Position, MAX(Playerrating) AS BestPlayerRate
//         FROM Players
//         GROUP BY Position
//     ) p
//     JOIN Players pl ON p.Position = pl.Position AND p.BestPlayerRate = pl.Playerrate;
// END //

// DELIMITER ;



// Query to find the best playerrate for each position
$callProcedure = "CALL MGetBestPlayersByPosition()";
$positionResult = $conn->query($callProcedure);

if ($positionResult->num_rows > 0) {
    echo "<table border='1'> 
    <tr> 
        <th colspan='3'>Best Player for Each Position</th> 
    </tr> 
    <tr>
        <th>Position</th>
        <th>Player Name</th>
        <th>Player Rating</th>
    </tr>";

    while($row = $positionResult->fetch_assoc()) {
    echo "<tr>
        <td>".$row["Position"]."</td>
        <td>".$row["PlayerName"]."</td>
        <td>".$row["Playerrating"]."</td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "0 results found for best players.";
}
}

if(isset($_POST['getTeamTable'])){
        $teamName = $_POST['teamName'];

        // Query to get the last table for the specified team
        $getTeamTableQuery = "SELECT * FROM last WHERE teamname = '$teamName'";
        $teamTableResult = $conn->query($getTeamTableQuery);

        if ($teamTableResult->num_rows > 0) {
            echo "<table align='center' border='2px' style='width:1000px; line-height:40px; text-align: center;'> 
                <tr> 
                    <th colspan='5'>$teamName Last 5 Games</th> 
                </tr> 
                <tr>
                    <th>l_win</th>
                    <th>l_draw</th>
                    <th>l_lose</th>
                    <th>l_stats</th>
                </tr>";

            while($row = $teamTableResult->fetch_assoc()) {
                $matches = explode(")", $row["l_stats"]);

                echo "<tr>
                        <td>".$row["l_win"]."</td>
                        <td>".$row["l_lose"]."</td>
                        <td>".$row["l_draw"]."</td>
                        <td>";

                foreach ($matches as $match) {
                    // Skip empty entries
                    if (!empty($match)) {
                        echo $match . ")<br>";
                    }
                }

                echo "</td></tr>";
            }
            echo "</table>";
        } else {
            echo "No results found for $teamName";
        }
    }
?>


<form method="post" class="player-form">
        <label for="playerSelect">Select a Player:</label>
        <select name="playerSelect">
            <?php
            // Fetch player names from the database
            $playerNamesQuery = "SELECT CONCAT(FirstName, ' ', LastName) AS FullName FROM Players";
            $playerNamesResult = $conn->query($playerNamesQuery);

            if ($playerNamesResult->num_rows > 0) {
                while ($playerRow = $playerNamesResult->fetch_assoc()) {
                    echo "<option value='" . $playerRow['FullName'] . "'>" . $playerRow['FullName'] . "</option>";
                }
            }
            ?>
        </select>
        <input type="submit" name="getPlayerRating" value="Get Player Rating">
    </form>


    <?php
    // Check if the button to get player rating is clicked
    if (isset($_POST['getPlayerRating'])) {
        $selectedPlayer = $_POST['playerSelect'];
    
        // Fetch player information including player rating
        $getPlayerInfoQuery = "SELECT * FROM Players WHERE CONCAT(FirstName, ' ', LastName) = '$selectedPlayer'";
        $playerInfoResult = $conn->query($getPlayerInfoQuery);
    
        if ($playerInfoResult->num_rows > 0) {
            $playerInfo = $playerInfoResult->fetch_assoc();
    
            // Calculate player rating based on the provided formula
            $playerRating = round(
                ($playerInfo['Goals'] / 60.0 * 3 +
                $playerInfo['Saves'] / 60.0 * 1.5 +
                $playerInfo['Tackles'] / 20.0 * 1.5 +
                ($playerInfo['Speed'] - 20) / 15.0 * 2 +
                $playerInfo['CrucialMoments'] / 10.0 * 2),
                2
            );
    
            // Display player information and calculated player rating
            echo "<div>";
            echo "<h3>$selectedPlayer Player Rating:</h3>";
            echo "<p>Goals: " . $playerInfo['Goals'] . "  Saves: " . $playerInfo['Saves'] . " Tackles: " . $playerInfo['Tackles'] ." Speed: " . $playerInfo['Speed'] .  " Crucial Moments: " . $playerInfo['CrucialMoments'] ."</p>"  ;
            echo "<p>Playerrate: " . $playerRating . "</p>";
            // Display other player information as needed
            echo "</div>";
        } else {
            echo "Player not found.";
        }
    }
    ?>