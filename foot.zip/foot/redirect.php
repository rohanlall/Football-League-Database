<?php

$Name = $_POST['Name'];
$PN = $_POST['Phone_Number'];
$email = $_POST['email'];
$pass = $_POST['pass'];
echo $Name;

// Establish a MySQLi connection
$conn = new mysqli('localhost', 'root', 'Samarth@123', 'foot1');

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data

// Validate data (perform more extensive validation as needed)
if (empty($Name) || empty($PN) || empty($email) || empty($pass)) {
    echo "All fields are required.";
} else {
    // Insert data into the 'login' table
    $sql = "INSERT INTO login (Name_s, PH, email, pass) 
            VALUES ('$Name', '$PN', '$email', '$pass')";

    if ($conn->query($sql) === TRUE) {
        // Check if the trigger already exists
        $checkTriggerSQL = "SELECT * FROM information_schema.triggers WHERE trigger_name = 'after_insert_login'";
        $result = $conn->query($checkTriggerSQL);

        if ($result->num_rows == 0) {
            // Trigger does not exist, create it
            $triggerSQL = "CREATE TRIGGER after_insert_login
                           AFTER INSERT ON login
                           FOR EACH ROW
                           INSERT INTO log (log_message) VALUES ('New record inserted into login table')";
            $conn->query($triggerSQL);
        } else {
            // Trigger already exists, handle accordingly
            echo "Trigger already exists.";
            // You may choose to drop the existing trigger and recreate it if needed
            // $conn->query("DROP TRIGGER IF EXISTS after_insert_login");
            // $conn->query("CREATE TRIGGER after_insert_login ...");
        }

        echo "New record inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the connection
    $conn->close();

    // Redirect back to register.html after form submission
    header("Location: index.php");
    exit();
}
?>
